
#ifndef ENEMYS_H
#define ENEMYS_H




class enemys
{
public:
    enemys();
};

#endif // ENEMYS_H
