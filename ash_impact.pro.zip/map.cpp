
#include "map.h"


map::map()
{
    map1.load(":/map/res/map/m4.png");
    map2.load(":/map/res/map/5.png");
    map3.load(":/map/res/map/end.png");
}

