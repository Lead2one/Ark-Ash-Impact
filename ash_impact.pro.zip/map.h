
#ifndef MAP_H
#define MAP_H
#include <QPixmap>



class map
{
public:
    map();
    QPixmap map1;
    QPixmap map2;
    QPixmap map3;
    int map1_x=0;


};

#endif // MAP_H
