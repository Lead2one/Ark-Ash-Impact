
#ifndef CONFIG_H
#define CONFIG_H

#define map_height 1500
#define map_width 910
#define gamename "Ash's dream"
#define map1path ":/map/res/map/m4.png"
#define gamespeed 5
#define walkfps 70
#define gameicon ":/ash/res/ash/ashicon.png"
#define slowspeed 25
#endif // CONFIG_H
